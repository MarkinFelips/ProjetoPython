import sys, os

sys.path.append(os.path.abspath(os.curdir))